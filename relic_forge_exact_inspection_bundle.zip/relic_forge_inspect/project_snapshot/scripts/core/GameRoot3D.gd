class_name RVGameRoot3D
extends Node3D
const FinalGameHUDScene := preload("res://scenes/ui/GameHUD3D.tscn")
const FinalUIPanelRootScene := preload("res://scenes/ui/UIPanelRoot3D.tscn")
const StationAccessSystemScript := preload("res://scripts/systems/StationAccessSystem3D.gd")
const GemProgressionSystemScript := preload("res://scripts/systems/GemProgressionSystem3D.gd")
const UIAccessSystemScript := preload("res://scripts/systems/UIAccessSystem3D.gd")
const InventoryGridSystemScript := preload("res://scripts/systems/InventoryGridSystem3D.gd")
var _rf_087r_hud: Node = null
var _rf_087r_ui: Node = null


const GameStateScript := preload("res://scripts/core/GameState3D.gd")
const SaveSystemScript := preload("res://scripts/systems/SaveSystem3D.gd")
const SkillGemSystemScript := preload("res://scripts/systems/SkillGemSystem3D.gd")
const CraftingSystemScript := preload("res://scripts/systems/CraftingSystem3D.gd")
const MapLoopSystemScript := preload("res://scripts/systems/MapLoopSystem3D.gd")
const ItemDBScript := preload("res://scripts/data/ItemDB3D.gd")
const MapDBScript := preload("res://scripts/data/MapDB3D.gd")
const VisualFoundationLayerScript := preload("res://scripts/visual/VisualFoundationLayer3D.gd")
const HubGreyboxPassScript := preload("res://scripts/visual/HubGreyboxPass3D.gd")
const CombatArenaGreyboxPassScript := preload("res://scripts/visual/CombatArenaGreyboxPass3D.gd")
const SkillVFXLayerScript := preload("res://scripts/visual/SkillVFXLayer3D.gd")
const EnemyReadabilityLayerScript := preload("res://scripts/visual/EnemyReadabilityLayer3D.gd")
const LootPresentationLayerScript: GDScript = preload("res://scripts/visual/LootPresentationLayer3D.gd")
const CombatFeedbackLayerScript := preload("res://scripts/visual/CombatFeedbackLayer3D.gd")
const CombatDirectorLayerScript := preload("res://scripts/visual/CombatDirectorLayer3D.gd")
const RuntimeLayerManagerScript := preload("res://scripts/core/RuntimeLayerManager3D.gd")

@onready var hub: Node3D = $Hub
@onready var combat: Node3D = $Combat
@onready var player: Node3D = $Player
@onready var camera: Camera3D = $Camera3D
@onready var pet: Node3D = $PickupPet
@onready var status_label: Label = get_node_or_null("UI/Root/StatusLabel") as Label
@onready var help_label: Label = get_node_or_null("UI/Root/HelpLabel") as Label
@onready var panel_root: PanelContainer = get_node_or_null("UI/Root/PanelRoot") as PanelContainer
@onready var panel_text: Label = get_node_or_null("UI/Root/PanelRoot/PanelText") as Label

var state: Object = GameStateScript.new()
var autosave_timer: float = 0.0
var _rf_096a_visual_layer: Node3D = null
var _rf_096b_hub_greybox: Node3D = null
var _rf_096c_combat_greybox: Node3D = null
var _rf_096d_skill_vfx_layer: Node3D = null
var _rf_096e_enemy_readability_layer: Node3D = null
var _rf_096f_loot_presentation_layer: Node3D = null
var _rf_096g_combat_feedback_layer: Node3D = null
var _rf_097a_combat_director_layer: Node3D = null
var _rf_097b_runtime_layer_manager: Node = null

func _rf_pre_091a_ready() -> void:
	_rf_087r_ensure_final_ui()
	SaveSystemScript.load_into(state)
	state.call("ensure_defaults")
	_return_to_hub(false)
	set_process(true)

func _rf_pre_091a_process(delta: float) -> void:
	_update_notice(delta)
	_update_player(delta)
	if str(state.get("mode")) == "combat":
		combat.call("update_combat", state, player, delta)
		if pet != null and pet.has_method("update_pet"):
			pet.call("update_pet", player, combat, state, delta)
	_update_camera(delta)
	_update_ui()
	_rf_087r_update_final_ui(delta)
	autosave_timer += delta
	if autosave_timer >= 12.0:
		autosave_timer = 0.0
		SaveSystemScript.save(state)

func _update_notice(delta: float) -> void:
	if _rf_087v_float(state.get("notice_time")) > 0.0:
		state.set("notice_time", max(0.0, _rf_087v_float(state.get("notice_time")) - delta))

func _update_player(delta: float) -> void:
	if player == null: return
	var blocked: bool = str(state.get("panel_mode")) != ""
	var move: Vector3 = Vector3.ZERO
	if not blocked:
		if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP): move.z -= 1.0
		if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN): move.z += 1.0
		if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT): move.x -= 1.0
		if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT): move.x += 1.0
	if player.has_method("move_world"):
		player.call("move_world", move, _rf_087v_float(state.get("move_speed")), delta)
	if str(state.get("mode")) == "combat" and combat != null and combat.has_method("constrain_player_position"):
		player.global_position = combat.call("constrain_player_position", player.global_position)
	state.set("player_pos", player.global_position)

func _update_camera(delta: float) -> void:
	if camera == null or player == null: return
	var target: Vector3 = player.global_position + Vector3(0, 10.5, 9.5)
	camera.global_position = camera.global_position.lerp(target, clampf(delta * 6.0, 0.0, 1.0))
	camera.look_at(player.global_position + Vector3(0, 0.5, 0), Vector3.UP)

func _rf_pre_091a_unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey:
		var key_event: InputEventKey = event
		if key_event.pressed and not key_event.echo:
			_handle_key(key_event.keycode)
	elif event is InputEventMouseButton:
		var mouse_event: InputEventMouseButton = event
		if mouse_event.pressed and mouse_event.button_index == MOUSE_BUTTON_LEFT and str(state.get("mode")) == "combat" and str(state.get("panel_mode")) == "":
			_cast_selected_skill(_mouse_world())

func _handle_key(keycode: int) -> void:
	if str(state.get("panel_mode")) != "":
		_handle_panel_key(keycode)
		return
	match keycode:
		KEY_F5:
			SaveSystemScript.save(state)
			state.call("add_notice", "Saved")
		KEY_F8:
			state.set("panel_mode", "")
		KEY_Z:
			state.call("use_health_flask")
		KEY_X:
			state.call("use_mana_flask")
		KEY_T:
			state.call("add_notice", "Use the Map Device station in the hub. Press E to extract when a map is clear.")
		KEY_E:
			if str(state.get("mode")) == "combat":
				if bool(combat.get("room_clear")):
					_return_to_hub(true)
				else:
					combat.call("manual_pickup_near", state, player.global_position)
			else:
				return
		KEY_SPACE:
			if str(state.get("mode")) == "combat": _cast_selected_skill(_mouse_world())
		KEY_Q:
			var prev_slot: int = wrapi(_rf_087v_int(state.get("selected_skill_slot")) - 1, 0, 5)
			state.set("selected_skill_slot", prev_slot)
			state.set("selected_hotbar_slot", prev_slot)
		KEY_R:
			var next_slot: int = wrapi(_rf_087v_int(state.get("selected_skill_slot")) + 1, 0, 5)
			state.set("selected_skill_slot", next_slot)
			state.set("selected_hotbar_slot", next_slot)
		KEY_1, KEY_2, KEY_3, KEY_4, KEY_5:
			state.set("selected_skill_slot", keycode - KEY_1)
			state.set("selected_hotbar_slot", keycode - KEY_1)
		KEY_I:
			_toggle_panel("inventory")
		KEY_K:
			_toggle_panel("skills")
		KEY_C:
			state.call("add_notice", "Walk to the Character Shrine in the hub.")
		KEY_M:
			state.call("add_notice", "Walk to the Map Device in the hub.")
		KEY_F:
			state.call("add_notice", "Walk to the Forge in the hub.")
		KEY_H:
			state.call("add_notice", "Inventory [I] and Gems [K] are global. Other stations are in the hub.")
		KEY_BRACKETLEFT:
			_cycle_cursor(-1)
		KEY_BRACKETRIGHT:
			_cycle_cursor(1)
		KEY_U:
			state.call("equip_backpack_index", _rf_087v_int(state.get("inventory_cursor")))

func _handle_panel_key(keycode: int) -> void:
	var mode: String = str(state.get("panel_mode"))
	if keycode == KEY_ESCAPE:
		state.set("panel_mode", "")
		return
	if (keycode == KEY_I and mode == "inventory") or (keycode == KEY_K and mode == "skills"):
		state.set("panel_mode", "")
		return
	if mode == "inventory":
		if keycode == KEY_BRACKETLEFT: _cycle_cursor(-1)
		elif keycode == KEY_BRACKETRIGHT: _cycle_cursor(1)
		elif keycode == KEY_U:
			state.call("equip_backpack_index", _rf_087v_int(state.get("inventory_cursor")))
		elif keycode == KEY_Y:
			InventoryGridSystemScript.appraise_selected(state)
		elif keycode == KEY_L:
			InventoryGridSystemScript.toggle_locked_selected(state)
		elif keycode == KEY_V:
			InventoryGridSystemScript.toggle_favorite_selected(state)
		elif keycode == KEY_DELETE or keycode == KEY_BACKSPACE:
			InventoryGridSystemScript.drop_selected(state)
	elif mode == "skills":
		if keycode >= KEY_1 and keycode <= KEY_5:
			state.set("selected_skill_slot", keycode - KEY_1)
			state.set("selected_hotbar_slot", keycode - KEY_1)
		elif keycode == KEY_A: SkillGemSystemScript.cycle_active_slot_gem(state, -1)
		elif keycode == KEY_D: SkillGemSystemScript.cycle_active_slot_gem(state, 1)
		elif keycode == KEY_S: SkillGemSystemScript.add_next_valid_support(state)
		elif keycode == KEY_W: SkillGemSystemScript.remove_last_support(state)
		elif keycode == KEY_G: SkillGemSystemScript.toggle_next_spirit(state)
		elif keycode == KEY_Y: state.call("add_notice", "Use the Gem screen with the mouse: select an Uncut Gem, then choose what to carve.")
		elif keycode == KEY_T: state.call("add_notice", "Use the Gem screen with the mouse: select an Uncut Support Gem, then choose a support.")
		elif keycode == KEY_B: state.call("add_notice", "Use the Gem screen with the mouse: select an Uncut Spirit Gem, then choose a spirit gem.")
	elif mode == "maps":
		var maps: Array = Array(state.get("map_stash"))
		if not maps.is_empty():
			if keycode == KEY_BRACKETLEFT: state.set("map_cursor", wrapi(_rf_087v_int(state.get("map_cursor")) - 1, 0, maps.size()))
			elif keycode == KEY_BRACKETRIGHT: state.set("map_cursor", wrapi(_rf_087v_int(state.get("map_cursor")) + 1, 0, maps.size()))
			elif keycode == KEY_T: state.call("add_notice", "Click Launch Map from the Map Device.")
	elif mode == "crafting":
		state.call("add_notice", "Use the Forge buttons with the mouse.")

func _cycle_cursor(dir: int) -> void:
	var backpack: Array = Array(state.get("backpack"))
	if backpack.is_empty(): return
	state.set("inventory_cursor", wrapi(_rf_087v_int(state.get("inventory_cursor")) + dir, 0, backpack.size()))

func _toggle_panel(mode_name: String) -> void:
	UIAccessSystemScript.toggle_panel(state, mode_name)

func _start_map() -> void:
	var activity: Dictionary = MapLoopSystemScript.start_selected_map(state)
	if activity.is_empty(): return
	state.set("mode", "combat")
	hub.visible = false
	combat.visible = true
	player.global_position = Vector3(0, 0, -7.0)
	pet.global_position = player.global_position + Vector3(-1, 0.5, 0.5)
	combat.call("start_map", state, activity)
	state.call("full_restore")
	state.call("add_notice", "Entered " + str(activity.get("display_name", "Map")))

func _return_to_hub(save_now: bool) -> void:
	state.set("mode", "hub")
	state.set("panel_mode", "")
	hub.visible = true
	combat.call("stop_map")
	combat.visible = false
	player.global_position = Vector3(0, 0, 0)
	pet.global_position = player.global_position + Vector3(-1, 0.5, 0.5)
	state.call("full_restore")
	if save_now: SaveSystemScript.save(state)

func _cast_selected_skill(aim: Vector3) -> void:
	var cast_data: Dictionary = SkillGemSystemScript.selected_cast_data(state)
	combat.call("cast_skill", state, player.global_position, aim, cast_data)
	GemProgressionSystemScript.award_selected_skill_xp(state, 5)

func _mouse_world() -> Vector3:
	var mouse: Vector2 = get_viewport().get_mouse_position()
	var from: Vector3 = camera.project_ray_origin(mouse)
	var dir: Vector3 = camera.project_ray_normal(mouse)
	if abs(dir.y) < 0.001:
		return player.global_position + Vector3(0, 0, -3)
	var t: float = -from.y / dir.y
	return from + dir * t

func _update_ui() -> void:
	_rf_087r_hide_legacy_text_ui()
	return

func _inventory_text() -> String:
	var text: String = "INVENTORY\n[ / ] Select · U Equip · F Forge\n\nEquipped:\n"
	var equipped: Dictionary = Dictionary(state.get("equipped"))
	for slot_key: Variant in equipped.keys():
		var item: Dictionary = Dictionary(equipped[slot_key])
		text += "  " + str(slot_key) + ": " + str(item.get("display_name", "—")) + "\n"
	text += "\nBackpack:\n"
	var backpack: Array = Array(state.get("backpack"))
	var cursor: int = _rf_087v_int(state.get("inventory_cursor"))
	if backpack.is_empty():
		text += "  empty\n"
	else:
		for i: int in range(backpack.size()):
			var item2: Dictionary = Dictionary(backpack[i])
			text += ("> " if i == cursor else "  ") + str(i + 1) + ". " + str(item2.get("display_name", "Item")) + "\n"
	text += "\nSelected:\n" + ItemDBScript.item_detail(state.call("selected_backpack_item"))
	return text

func _character_text() -> String:
	var text: String = "CHARACTER\n"
	text += str(state.get("class_display_name")) + " · Level " + str(state.get("level")) + " · XP " + str(_rf_087v_int(state.get("xp"))) + "/" + str(_rf_087v_int(state.call("xp_to_next"))) + "\n"
	text += "HP " + str(_rf_087v_int(state.get("max_hp"))) + " · Mana " + str(_rf_087v_int(state.get("max_mana"))) + " · Armor " + str(_rf_087v_int(state.get("armor"))) + " · Speed " + str(snappedf(_rf_087v_float(state.get("move_speed")), 0.01)) + "\n\nBuild Stats:\n"
	for key_value: Variant in Dictionary(state.get("build_stats")).keys():
		text += "  " + str(key_value) + ": " + str(Dictionary(state.get("build_stats"))[key_value]) + "\n"
	return text

func _help_text() -> String:
	return "HELP\nWASD move\nLeftClick/Space cast\n1-4 select skill\nQ/R cycle skill\nZ/X flasks\nT start/leave map\nE interact/pickup/exit\nI inventory\nK skill gems\nF forge\nM maps\nC character\n"

func _rf_087r_ensure_final_ui() -> void:
	if _rf_087r_hud == null or not is_instance_valid(_rf_087r_hud):
		_rf_087r_hud = get_node_or_null("FinalGameHUD3D")
		if _rf_087r_hud == null:
			_rf_087r_hud = FinalGameHUDScene.instantiate()
			_rf_087r_hud.name = "FinalGameHUD3D"
			add_child(_rf_087r_hud)
	if _rf_087r_ui == null or not is_instance_valid(_rf_087r_ui):
		_rf_087r_ui = get_node_or_null("FinalUIPanelRoot3D")
		if _rf_087r_ui == null:
			_rf_087r_ui = FinalUIPanelRootScene.instantiate()
			_rf_087r_ui.name = "FinalUIPanelRoot3D"
			add_child(_rf_087r_ui)
	if _rf_087r_hud != null and _rf_087r_hud.has_method("bind_state"):
		_rf_087r_hud.call("bind_state", state)
	if _rf_087r_ui != null and _rf_087r_ui.has_method("bind_state"):
		_rf_087r_ui.call("bind_state", state)

func _rf_087r_update_final_ui(_delta: float) -> void:
	_rf_099a_disable_legacy_embedded_ui()
	_rf_087r_ensure_final_ui()
	if _rf_087r_hud != null and _rf_087r_hud.has_method("update_from_state"):
		_rf_087r_hud.call("update_from_state", state)
	if _rf_087r_ui != null and _rf_087r_ui.has_method("update_from_state"):
		_rf_087r_ui.call("update_from_state", state)
	_rf_087r_hide_legacy_text_ui()

func _rf_087r_hide_legacy_text_ui() -> void:
	var legacy_paths: Array[String] = [
		"UI",
		"UI/Root",
		"UI/Root/StatusLabel",
		"UI/Root/HelpLabel",
		"UI/Root/PanelRoot",
		"UI/Root/PanelRoot/PanelText",
		"HUD",
		"HUD3D",
		"SimpleHUD3D",
		"PanelRoot",
		"UIPanelRoot",
		"SkillLoadoutPanel",
		"SkillLoadoutPanel3D",
		"FinalUIPanelRoot",
	]
	for path_value: String in legacy_paths:
		var node: Node = get_node_or_null(path_value)
		if node == null:
			continue
		if node == _rf_087r_hud or node == _rf_087r_ui:
			continue
		if node is CanvasItem:
			(node as CanvasItem).visible = false
		if node is Control:
			(node as Control).mouse_filter = Control.MOUSE_FILTER_IGNORE
	for child: Node in get_children():
		if child == _rf_087r_hud or child == _rf_087r_ui:
			continue
		var n: String = str(child.name).to_lower()
		if n in ["ui", "hud", "hud3d", "simplehud3d", "skillloadoutpanel", "skillloadoutpanel3d", "finaluipanelroot"]:
			if child is CanvasItem:
				(child as CanvasItem).visible = false
			if child is Control:
				(child as Control).mouse_filter = Control.MOUSE_FILTER_IGNORE

func _rf_087u_float(value: Variant, fallback: float = 0.0) -> float:
	if value == null:
		return fallback
	match typeof(value):
		TYPE_FLOAT:
			return value
		TYPE_INT:
			return float(value)
		TYPE_BOOL:
			return 1.0 if bool(value) else 0.0
		TYPE_STRING:
			var s: String = str(value)
			if s.is_valid_float():
				return s.to_float()
			if s.is_valid_int():
				return float(s.to_int())
			return fallback
		_:
			return fallback

func _rf_087u_int(value: Variant, fallback: int = 0) -> int:
	if value == null:
		return fallback
	match typeof(value):
		TYPE_INT:
			return value
		TYPE_FLOAT:
			return int(round(value))
		TYPE_BOOL:
			return 1 if bool(value) else 0
		TYPE_STRING:
			var s: String = str(value)
			if s.is_valid_int():
				return s.to_int()
			if s.is_valid_float():
				return int(round(s.to_float()))
			return fallback
		_:
			return fallback

func _rf_087v_float(value: Variant, fallback: float = 0.0) -> float:
	if value == null:
		return fallback
	match typeof(value):
		TYPE_FLOAT:
			return value
		TYPE_INT:
			return float(value)
		TYPE_BOOL:
			return 1.0 if bool(value) else 0.0
		TYPE_STRING:
			var s: String = str(value)
			if s.is_valid_float():
				return s.to_float()
			if s.is_valid_int():
				return float(s.to_int())
			return fallback
		_:
			return fallback

func _rf_087v_int(value: Variant, fallback: int = 0) -> int:
	if value == null:
		return fallback
	match typeof(value):
		TYPE_INT:
			return value
		TYPE_FLOAT:
			return int(round(value))
		TYPE_BOOL:
			return 1 if bool(value) else 0
		TYPE_STRING:
			var s: String = str(value)
			if s.is_valid_int():
				return s.to_int()
			if s.is_valid_float():
				return int(round(s.to_float()))
			return fallback
		_:
			return fallback


func _ready() -> void:
	call_deferred("_rf_097b_ensure_runtime_layer_manager")
	call_deferred("_rf_097a_ensure_combat_director_layer")
	call_deferred("_rf_096g_ensure_combat_feedback_layer")
	call_deferred("_rf_096f_ensure_loot_presentation_layer")
	call_deferred("_rf_096e_ensure_enemy_readability_layer")
	call_deferred("_rf_096d_ensure_skill_vfx_layer")
	call_deferred("_rf_096c_ensure_combat_greybox")
	call_deferred("_rf_096b_ensure_hub_greybox")
	call_deferred("_rf_096a_ensure_visual_foundation")
	if has_method("_rf_pre_091a_ready"):
		_rf_pre_091a_ready()
	_rf_091a_setup_physical_station_refine()


func _process(delta: float) -> void:
	if has_method("_rf_pre_091a_process"):
		_rf_pre_091a_process(delta)
	_rf_091a_update_physical_station_refine()


func _unhandled_input(event: InputEvent) -> void:
	var s: Object = _rf_091a_state()
	var p: Node3D = _rf_091a_player()
	if StationAccessSystemScript.handle_station_input(event, self, s, p):
		get_viewport().set_input_as_handled()
		return
	if has_method("_rf_pre_091a_unhandled_input"):
		_rf_pre_091a_unhandled_input(event)


func _rf_091a_setup_physical_station_refine() -> void:
	var s: Object = _rf_091a_state()
	StationAccessSystemScript.ensure_physical_stations(self)
	if s != null:
		GemProgressionSystemScript.ensure_progression_defaults(s)
		GemProgressionSystemScript.ensure_starter_gem_items(s)

func _rf_091a_update_physical_station_refine() -> void:
	var s: Object = _rf_091a_state()
	if s == null:
		return
	StationAccessSystemScript.update_access(self, s, _rf_091a_player())

func _rf_091a_request_panel_mode(mode: String) -> void:
	var s: Object = _rf_091a_state()
	if s == null:
		return
	UIAccessSystemScript.request_panel(s, mode)

func _rf_091a_state() -> Object:
	var v: Variant = get("state")
	return v as Object

func _rf_091a_player() -> Node3D:
	var v: Variant = get("player")
	if v is Node3D:
		return v as Node3D
	return get_node_or_null("Player") as Node3D


func _rf_096a_ensure_visual_foundation() -> void:
	if _rf_096a_visual_layer != null and is_instance_valid(_rf_096a_visual_layer):
		return

	_rf_096a_visual_layer = get_node_or_null("VisualFoundationLayer096A") as Node3D
	if _rf_096a_visual_layer == null:
		_rf_096a_visual_layer = VisualFoundationLayerScript.new()
		_rf_096a_visual_layer.name = "VisualFoundationLayer096A"
		add_child(_rf_096a_visual_layer)

	if _rf_096a_visual_layer != null and _rf_096a_visual_layer.has_method("bind_game"):
		_rf_096a_visual_layer.call("bind_game", self)


func _rf_096b_ensure_hub_greybox() -> void:
	if _rf_096b_hub_greybox != null and is_instance_valid(_rf_096b_hub_greybox):
		return

	_rf_096b_hub_greybox = get_node_or_null("HubGreyboxPass096B") as Node3D
	if _rf_096b_hub_greybox == null:
		_rf_096b_hub_greybox = HubGreyboxPassScript.new()
		_rf_096b_hub_greybox.name = "HubGreyboxPass096B"
		add_child(_rf_096b_hub_greybox)

	if _rf_096b_hub_greybox != null and _rf_096b_hub_greybox.has_method("bind_game"):
		_rf_096b_hub_greybox.call("bind_game", self)



func _rf_096c_ensure_combat_greybox() -> void:
	if _rf_096c_combat_greybox != null and is_instance_valid(_rf_096c_combat_greybox):
		return

	_rf_096c_combat_greybox = get_node_or_null("CombatArenaGreyboxPass096C") as Node3D
	if _rf_096c_combat_greybox == null:
		_rf_096c_combat_greybox = CombatArenaGreyboxPassScript.new()
		_rf_096c_combat_greybox.name = "CombatArenaGreyboxPass096C"
		add_child(_rf_096c_combat_greybox)

	if _rf_096c_combat_greybox != null and _rf_096c_combat_greybox.has_method("bind_game"):
		_rf_096c_combat_greybox.call("bind_game", self)



func _rf_096d_ensure_skill_vfx_layer() -> void:
	if _rf_096d_skill_vfx_layer != null and is_instance_valid(_rf_096d_skill_vfx_layer):
		return

	_rf_096d_skill_vfx_layer = get_node_or_null("SkillVFXLayer096D") as Node3D
	if _rf_096d_skill_vfx_layer == null:
		_rf_096d_skill_vfx_layer = SkillVFXLayerScript.new()
		_rf_096d_skill_vfx_layer.name = "SkillVFXLayer096D"
		add_child(_rf_096d_skill_vfx_layer)

	if _rf_096d_skill_vfx_layer != null and _rf_096d_skill_vfx_layer.has_method("bind_game"):
		_rf_096d_skill_vfx_layer.call("bind_game", self)



func _rf_096e_ensure_enemy_readability_layer() -> void:
	if _rf_096e_enemy_readability_layer != null and is_instance_valid(_rf_096e_enemy_readability_layer):
		return

	_rf_096e_enemy_readability_layer = get_node_or_null("EnemyReadabilityLayer096E") as Node3D
	if _rf_096e_enemy_readability_layer == null:
		_rf_096e_enemy_readability_layer = EnemyReadabilityLayerScript.new()
		_rf_096e_enemy_readability_layer.name = "EnemyReadabilityLayer096E"
		add_child(_rf_096e_enemy_readability_layer)

	if _rf_096e_enemy_readability_layer != null and _rf_096e_enemy_readability_layer.has_method("bind_game"):
		_rf_096e_enemy_readability_layer.call("bind_game", self)



func _rf_096f_ensure_loot_presentation_layer() -> void:
	if _rf_096f_loot_presentation_layer != null and is_instance_valid(_rf_096f_loot_presentation_layer):
		return

	_rf_096f_loot_presentation_layer = get_node_or_null("LootPresentationLayer096F") as Node3D
	if _rf_096f_loot_presentation_layer == null:
		_rf_096f_loot_presentation_layer = LootPresentationLayerScript.new()
		_rf_096f_loot_presentation_layer.name = "LootPresentationLayer096F"
		add_child(_rf_096f_loot_presentation_layer)

	if _rf_096f_loot_presentation_layer != null and _rf_096f_loot_presentation_layer.has_method("bind_game"):
		_rf_096f_loot_presentation_layer.call("bind_game", self)



func _rf_096g_ensure_combat_feedback_layer() -> void:
	if _rf_096g_combat_feedback_layer != null and is_instance_valid(_rf_096g_combat_feedback_layer):
		return

	_rf_096g_combat_feedback_layer = get_node_or_null("CombatFeedbackLayer096G") as Node3D
	if _rf_096g_combat_feedback_layer == null:
		_rf_096g_combat_feedback_layer = CombatFeedbackLayerScript.new()
		_rf_096g_combat_feedback_layer.name = "CombatFeedbackLayer096G"
		add_child(_rf_096g_combat_feedback_layer)

	if _rf_096g_combat_feedback_layer != null and _rf_096g_combat_feedback_layer.has_method("bind_game"):
		_rf_096g_combat_feedback_layer.call("bind_game", self)



func _rf_097a_ensure_combat_director_layer() -> void:
	if _rf_097a_combat_director_layer != null and is_instance_valid(_rf_097a_combat_director_layer):
		return

	_rf_097a_combat_director_layer = get_node_or_null("CombatDirectorLayer097A") as Node3D
	if _rf_097a_combat_director_layer == null:
		_rf_097a_combat_director_layer = CombatDirectorLayerScript.new()
		_rf_097a_combat_director_layer.name = "CombatDirectorLayer097A"
		add_child(_rf_097a_combat_director_layer)

	if _rf_097a_combat_director_layer != null and _rf_097a_combat_director_layer.has_method("bind_game"):
		_rf_097a_combat_director_layer.call("bind_game", self)



func _rf_097b_ensure_runtime_layer_manager() -> void:
	if _rf_097b_runtime_layer_manager != null and is_instance_valid(_rf_097b_runtime_layer_manager):
		return

	_rf_097b_runtime_layer_manager = get_node_or_null("RuntimeLayerManager097B")
	if _rf_097b_runtime_layer_manager == null:
		_rf_097b_runtime_layer_manager = RuntimeLayerManagerScript.new()
		_rf_097b_runtime_layer_manager.name = "RuntimeLayerManager097B"
		add_child(_rf_097b_runtime_layer_manager)

	if _rf_097b_runtime_layer_manager != null and _rf_097b_runtime_layer_manager.has_method("bind_game"):
		_rf_097b_runtime_layer_manager.call("bind_game", self)


func _rf_099a_disable_legacy_embedded_ui() -> void:
	var legacy_ui: CanvasLayer = get_node_or_null("UI") as CanvasLayer
	if legacy_ui != null:
		legacy_ui.visible = false
		for child: Node in legacy_ui.get_children():
			if child is Control:
				(child as Control).mouse_filter = Control.MOUSE_FILTER_IGNORE
	var legacy_paths: Array[String] = [
		"UI/Root/StatusLabel",
		"UI/Root/HelpLabel",
		"UI/Root/PanelRoot",
		"UI/Root/PanelRoot/PanelText"
	]
	for path: String in legacy_paths:
		var n: Node = get_node_or_null(path)
		if n is CanvasItem:
			(n as CanvasItem).visible = false
		if n is Control:
			(n as Control).mouse_filter = Control.MOUSE_FILTER_IGNORE
